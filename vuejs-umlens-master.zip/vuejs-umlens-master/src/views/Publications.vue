<template>
  <v-container>
        <v-row>
            <v-col cols="12">
                <div class="text-h3 text-center my-5">Publications</div>
            </v-col>
        </v-row>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>